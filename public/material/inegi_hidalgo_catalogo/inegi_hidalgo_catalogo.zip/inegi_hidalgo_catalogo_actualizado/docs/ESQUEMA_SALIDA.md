# Esquema de salida

## `hidalgo_asentamientos_humanos_localidades.json`

Estructura limpia para frontend/API:

```json
{
  "estado": "Hidalgo",
  "claveEntidad": "13",
  "claveGeoestadistica": "13",
  "tipo": "catalogo_asentamientos_humanos_localidades",
  "municipios": [
    {
      "municipio": "Acatlán",
      "claveMunicipio": "001",
      "claveGeoestadistica": "13001",
      "localidades": [
        {
          "claveGeoestadistica": "130010001",
          "claveLocalidad": "0001",
          "nombre": "Acatlán",
          "ambito": "URBANO",
          "periodo": "2015-06-01",
          "tipo": "localidad",
          "asentamientosHumanos": [
            {
              "claveAsentamiento": "0001",
              "nombre": "CENTRO",
              "tipoAsentamiento": "COLONIA",
              "periodo": "11/2022",
              "claveGeoestadistica": "1300100010001",
              "claveLocalidad": "0001",
              "claveGeoestadisticaLocalidad": "130010001",
              "localidad": "Acatlán",
              "tipo": "asentamiento"
            }
          ]
        }
      ],
      "resumen": {
        "total": 59,
        "localidades": 59,
        "asentamientos": 41,
        "urbanas": 1,
        "rurales": 58,
        "poblacionTotal": 22268
      }
    }
  ],
  "resumen": {
    "municipios": 84,
    "localidades": 5291,
    "asentamientos": 3843,
    "urbanas": 263,
    "rurales": 5028,
    "poblacionTotal": 3082756
  }
}
```

## Campos removidos del nivel localidad en JSON

No se publican en cada localidad:

```txt
latitud
longitud
altitud
pob_total
```

La población queda resumida en:

```txt
municipios[].resumen.poblacionTotal
resumen.poblacionTotal
```

## GeoJSON

### Sin DCAH

Genera puntos preliminares por localidad:

```bash
python scripts/generar_geojson_enriquecido.py --geometry punto
```

### Con DCAH como punto

```bash
python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry punto
```

### Con DCAH como polígono

```bash
python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry poligono
```

### Con DCAH en ambos formatos

```bash
python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry both
```


## `hidalgo_asentamientos_humanos_localidades.csv`

CSV plano combinado para Excel/BD.

```csv
estado,claveEntidad,municipio,claveMunicipio,claveGeoestadisticaMunicipio,localidad,claveLocalidad,claveGeoestadisticaLocalidad,ambito,periodoLocalidad,asentamientoHumano,claveAsentamiento,tipoAsentamiento,periodoAsentamiento,claveGeoestadisticaAsentamiento,tipoRegistro
Hidalgo,13,Pachuca de Soto,048,13048,Pachuca de Soto,0001,130480001,URBANO,2015-06-01,ADOLFO LÓPEZ MATEOS,0152,COLONIA,11/2024,1304800010152,asentamiento
```

No contiene latitud, longitud, altitud ni población por localidad.
