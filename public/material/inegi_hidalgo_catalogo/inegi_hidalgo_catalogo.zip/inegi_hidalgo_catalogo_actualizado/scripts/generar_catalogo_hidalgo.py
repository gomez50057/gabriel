from __future__ import annotations

import json
import sys
from pathlib import Path
from typing import Any, Dict, List

import pandas as pd
from tqdm import tqdm

# Allow running as: python scripts/generar_catalogo_hidalgo.py
SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils_inegi import (
    BASE_URL,
    CVE_ENT_HIDALGO,
    NOM_ENT_HIDALGO,
    clean_text,
    get_datos,
    make_session,
    normalize_asentamiento,
    normalize_localidad,
    normalize_municipio,
    parse_int,
    save_json,
)


OUTPUT_DIR = PROJECT_DIR / "data" / "output"
RAW_DIR = PROJECT_DIR / "data" / "raw"


def build_clean_json(municipios: List[Dict[str, Any]], localidades_rows: List[Dict[str, Any]], asentamientos_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Build the clean JSON requested by the user.

    It intentionally removes latitud, longitud, altitud and pob_total from localidad objects.
    Population is aggregated only at municipio and state summary levels.
    """
    locs_by_mun: Dict[str, List[Dict[str, Any]]] = {}
    asens_by_loc: Dict[str, List[Dict[str, Any]]] = {}

    for loc in localidades_rows:
        locs_by_mun.setdefault(loc["cve_mun"], []).append(loc)

    for asen in asentamientos_rows:
        asens_by_loc.setdefault(asen["cvegeo_loc"], []).append(asen)

    municipios_json: List[Dict[str, Any]] = []

    total_localidades = 0
    total_asentamientos = 0
    total_urbanas = 0
    total_rurales = 0
    total_poblacion = 0

    for mun in sorted(municipios, key=lambda x: x["cve_mun"]):
        cve_mun = mun["cve_mun"]
        mun_locs = sorted(locs_by_mun.get(cve_mun, []), key=lambda x: x["cve_loc"])

        localidades_json = []
        urbanas = 0
        rurales = 0
        poblacion_mun = 0
        asentamientos_mun = 0

        for loc in mun_locs:
            ambito = clean_text(loc.get("ambito")).upper()
            if ambito == "URBANO":
                urbanas += 1
            elif ambito == "RURAL":
                rurales += 1

            poblacion_mun += parse_int(loc.get("pob_total"))

            loc_asens = sorted(asens_by_loc.get(loc["cvegeo_loc"], []), key=lambda x: (x["tipo_asen"], x["nom_asen"], x["cve_asen"]))
            asentamientos_mun += len(loc_asens)

            asentamientos_json = [
                {
                    "claveAsentamiento": a["cve_asen"],
                    "nombre": a["nom_asen"],
                    "tipoAsentamiento": a["tipo_asen"],
                    "periodo": a["periodo"],
                    "claveGeoestadistica": a["cvegeo_asen"],
                    "claveLocalidad": a["cve_loc"],
                    "claveGeoestadisticaLocalidad": a["cvegeo_loc"],
                    "localidad": a["nom_loc"],
                    "tipo": "asentamiento",
                }
                for a in loc_asens
            ]

            localidades_json.append(
                {
                    "claveGeoestadistica": loc["cvegeo_loc"],
                    "claveLocalidad": loc["cve_loc"],
                    "nombre": loc["nom_loc"],
                    "ambito": ambito,
                    "periodo": loc["periodo"],
                    "tipo": "localidad",
                    "asentamientosHumanos": asentamientos_json,
                }
            )

        resumen_mun = {
            "total": len(localidades_json),
            "localidades": len(localidades_json),
            "asentamientos": asentamientos_mun,
            "urbanas": urbanas,
            "rurales": rurales,
            "poblacionTotal": poblacion_mun,
        }

        municipios_json.append(
            {
                "municipio": mun["nom_mun"],
                "claveMunicipio": mun["cve_mun"],
                "claveGeoestadistica": mun["cvegeo_mun"],
                "localidades": localidades_json,
                "resumen": resumen_mun,
            }
        )

        total_localidades += len(localidades_json)
        total_asentamientos += asentamientos_mun
        total_urbanas += urbanas
        total_rurales += rurales
        total_poblacion += poblacion_mun

    return {
        "estado": NOM_ENT_HIDALGO,
        "claveEntidad": CVE_ENT_HIDALGO,
        "claveGeoestadistica": CVE_ENT_HIDALGO,
        "tipo": "catalogo_asentamientos_humanos_localidades",
        "municipios": municipios_json,
        "resumen": {
            "municipios": len(municipios_json),
            "localidades": total_localidades,
            "asentamientos": total_asentamientos,
            "urbanas": total_urbanas,
            "rurales": total_rurales,
            "poblacionTotal": total_poblacion,
        },
    }



def build_combined_localidades_asentamientos_csv_rows(
    municipios: List[Dict[str, Any]],
    localidades_rows: List[Dict[str, Any]],
    asentamientos_rows: List[Dict[str, Any]],
) -> List[Dict[str, Any]]:
    """Build a flat CSV combining localidades and asentamientos humanos.

    Output rule:
    - One row per asentamiento humano.
    - If a localidad has no asentamientos, include one row for the localidad with blank settlement fields.
    - No latitud, longitud, altitud or pob_total at localidad level.
    """
    locs_by_mun: Dict[str, List[Dict[str, Any]]] = {}
    asens_by_loc: Dict[str, List[Dict[str, Any]]] = {}

    for loc in localidades_rows:
        locs_by_mun.setdefault(loc["cve_mun"], []).append(loc)

    for asen in asentamientos_rows:
        asens_by_loc.setdefault(asen["cvegeo_loc"], []).append(asen)

    rows: List[Dict[str, Any]] = []

    for mun in sorted(municipios, key=lambda x: x["cve_mun"]):
        mun_locs = sorted(locs_by_mun.get(mun["cve_mun"], []), key=lambda x: x["cve_loc"])

        for loc in mun_locs:
            loc_asens = sorted(
                asens_by_loc.get(loc["cvegeo_loc"], []),
                key=lambda x: (x["tipo_asen"], x["nom_asen"], x["cve_asen"]),
            )

            base_row = {
                "estado": NOM_ENT_HIDALGO,
                "claveEntidad": CVE_ENT_HIDALGO,
                "municipio": mun["nom_mun"],
                "claveMunicipio": mun["cve_mun"],
                "claveGeoestadisticaMunicipio": mun["cvegeo_mun"],
                "localidad": loc["nom_loc"],
                "claveLocalidad": loc["cve_loc"],
                "claveGeoestadisticaLocalidad": loc["cvegeo_loc"],
                "ambito": loc["ambito"],
                "periodoLocalidad": loc["periodo"],
            }

            if not loc_asens:
                rows.append(
                    {
                        **base_row,
                        "asentamientoHumano": "",
                        "claveAsentamiento": "",
                        "tipoAsentamiento": "",
                        "periodoAsentamiento": "",
                        "claveGeoestadisticaAsentamiento": "",
                        "tipoRegistro": "localidad_sin_asentamiento",
                    }
                )
                continue

            for asen in loc_asens:
                rows.append(
                    {
                        **base_row,
                        "asentamientoHumano": asen["nom_asen"],
                        "claveAsentamiento": asen["cve_asen"],
                        "tipoAsentamiento": asen["tipo_asen"],
                        "periodoAsentamiento": asen["periodo"],
                        "claveGeoestadisticaAsentamiento": asen["cvegeo_asen"],
                        "tipoRegistro": "asentamiento",
                    }
                )

    return rows



def generate_point_geojson_from_asentamientos(asentamientos_rows: List[Dict[str, Any]]) -> Dict[str, Any]:
    """Generate a preliminary point GeoJSON.

    The point is based on the locality coordinates, not the actual settlement geometry.
    """
    features = []

    for row in asentamientos_rows:
        lat = clean_text(row.get("latitud_loc"))
        lon = clean_text(row.get("longitud_loc"))

        try:
            lat_f = float(lat)
            lon_f = float(lon)
        except Exception:
            continue

        props = dict(row)
        props.update(
            {
                "geometria_modo": "punto_localidad_preliminar",
                "nota_geometria": "Punto heredado de la localidad; no representa polígono real del asentamiento humano.",
            }
        )

        features.append(
            {
                "type": "Feature",
                "properties": props,
                "geometry": {"type": "Point", "coordinates": [lon_f, lat_f]},
            }
        )

    return {
        "type": "FeatureCollection",
        "name": "hidalgo_asentamientos_humanos_enriquecido",
        "features": features,
    }


def main() -> None:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    RAW_DIR.mkdir(parents=True, exist_ok=True)

    session = make_session()

    municipios_url = f"{BASE_URL}/mgem/{CVE_ENT_HIDALGO}"
    municipios_raw = get_datos(municipios_url, session=session)
    municipios = [normalize_municipio(m) for m in municipios_raw if normalize_municipio(m)["cve_mun"]]

    localidades_rows: List[Dict[str, Any]] = []
    asentamientos_rows: List[Dict[str, Any]] = []

    for municipio in tqdm(municipios, desc="Descargando municipios de Hidalgo"):
        cve_mun = municipio["cve_mun"]

        localidades_url = f"{BASE_URL}/localidades/{CVE_ENT_HIDALGO}/{cve_mun}"
        localidades_raw = get_datos(localidades_url, session=session)
        localidades = [normalize_localidad(l, municipio) for l in localidades_raw]

        localidad_index = {l["cve_loc"]: l for l in localidades}
        localidades_rows.extend(localidades)

        asentamientos_url = f"{BASE_URL}/asentamientos/{CVE_ENT_HIDALGO}/{cve_mun}"
        asentamientos_raw = get_datos(asentamientos_url, session=session)
        asentamientos = [normalize_asentamiento(a, municipio, localidad_index) for a in asentamientos_raw]
        asentamientos_rows.extend(asentamientos)

    # Raw cache for audit
    save_json(RAW_DIR / "municipios_hidalgo.json", municipios)
    save_json(RAW_DIR / "localidades_hidalgo.json", localidades_rows)
    save_json(RAW_DIR / "asentamientos_humanos_hidalgo.json", asentamientos_rows)

    # CSV outputs
    pd.DataFrame(localidades_rows).to_csv(OUTPUT_DIR / "hidalgo_localidades.csv", index=False, encoding="utf-8-sig")
    pd.DataFrame(asentamientos_rows).to_csv(OUTPUT_DIR / "hidalgo_asentamientos_humanos.csv", index=False, encoding="utf-8-sig")

    # CSV combinado: localidades + asentamientos humanos, formato plano para Excel/BD.
    combined_rows = build_combined_localidades_asentamientos_csv_rows(
        municipios,
        localidades_rows,
        asentamientos_rows,
    )
    pd.DataFrame(combined_rows).to_csv(
        OUTPUT_DIR / "hidalgo_asentamientos_humanos_localidades.csv",
        index=False,
        encoding="utf-8-sig",
    )

    # Clean hierarchical JSON
    clean_json = build_clean_json(municipios, localidades_rows, asentamientos_rows)
    save_json(OUTPUT_DIR / "hidalgo_asentamientos_humanos_localidades.json", clean_json)

    # Preliminary point GeoJSON, so the main file exists even without DCAH.
    point_geojson = generate_point_geojson_from_asentamientos(asentamientos_rows)
    save_json(OUTPUT_DIR / "hidalgo_asentamientos_humanos_enriquecido_puntos.geojson", point_geojson)
    save_json(OUTPUT_DIR / "hidalgo_asentamientos_humanos_enriquecido.geojson", point_geojson)

    print("\nListo.")
    print(f"Municipios: {len(municipios)}")
    print(f"Localidades: {len(localidades_rows)}")
    print(f"Asentamientos humanos: {len(asentamientos_rows)}")
    print(f"CSV combinado: hidalgo_asentamientos_humanos_localidades.csv")
    print(f"Salida: {OUTPUT_DIR}")


if __name__ == "__main__":
    main()
