from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path


SCRIPT_DIR = Path(__file__).resolve().parent


def run(cmd):
    print("\n$", " ".join(cmd))
    subprocess.run(cmd, check=True)


def main() -> None:
    parser = argparse.ArgumentParser(description="Ejecuta el flujo completo del catálogo INEGI Hidalgo.")
    parser.add_argument("--dcah", default="", help="Ruta opcional a capa DCAH .shp/.gpkg para generar geometría real.")
    parser.add_argument("--geometry", choices=["punto", "poligono", "both"], default="both")
    args = parser.parse_args()

    py = sys.executable

    run([py, str(SCRIPT_DIR / "generar_catalogo_hidalgo.py")])

    geo_cmd = [py, str(SCRIPT_DIR / "generar_geojson_enriquecido.py"), "--geometry", args.geometry]
    if args.dcah:
        geo_cmd.extend(["--dcah", args.dcah])

    run(geo_cmd)


if __name__ == "__main__":
    main()
