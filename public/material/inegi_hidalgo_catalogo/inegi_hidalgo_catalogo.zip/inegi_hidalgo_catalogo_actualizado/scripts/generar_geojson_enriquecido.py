from __future__ import annotations

import argparse
import shutil
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pandas as pd

SCRIPT_DIR = Path(__file__).resolve().parent
PROJECT_DIR = SCRIPT_DIR.parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from utils_inegi import clean_text, save_json


OUTPUT_DIR_DEFAULT = PROJECT_DIR / "data" / "output"


def normalize_key(value: Any, length: Optional[int] = None) -> str:
    value = clean_text(value)
    if not value:
        return ""
    # Avoid scientific notation or floats when values were read as numeric.
    try:
        if "." in value:
            f = float(value)
            if f.is_integer():
                value = str(int(f))
    except Exception:
        pass
    return value.zfill(length) if length else value


def load_asentamientos(path: Path) -> pd.DataFrame:
    if not path.exists():
        raise FileNotFoundError(f"No existe el archivo de asentamientos: {path}")

    df = pd.read_csv(path, dtype=str).fillna("")

    required = [
        "cve_ent", "nom_ent", "cve_mun", "nom_mun", "cve_loc", "nom_loc",
        "cve_asen", "nom_asen", "tipo_asen", "periodo", "cvegeo_loc", "cvegeo_asen"
    ]

    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Faltan columnas en {path}: {missing}")

    return df


def row_to_properties(row: pd.Series) -> Dict[str, Any]:
    return {k: ("" if pd.isna(v) else str(v)) for k, v in row.to_dict().items()}


def point_geojson_from_locality(df: pd.DataFrame) -> Dict[str, Any]:
    features: List[Dict[str, Any]] = []

    for _, row in df.iterrows():
        lat = clean_text(row.get("latitud_loc"))
        lon = clean_text(row.get("longitud_loc"))

        try:
            lat_f = float(lat)
            lon_f = float(lon)
        except Exception:
            continue

        props = row_to_properties(row)
        props.update(
            {
                "geometria_modo": "punto_localidad_preliminar",
                "nota_geometria": "Punto heredado de la localidad; no representa polígono real del asentamiento humano.",
            }
        )

        features.append(
            {
                "type": "Feature",
                "properties": props,
                "geometry": {"type": "Point", "coordinates": [lon_f, lat_f]},
            }
        )

    return {
        "type": "FeatureCollection",
        "name": "hidalgo_asentamientos_humanos_enriquecido_puntos",
        "features": features,
    }


def import_geopandas():
    try:
        import geopandas as gpd
        from shapely.geometry import Point
        return gpd
    except Exception as exc:
        raise RuntimeError(
            "Para usar --dcah necesitas instalar dependencias GIS:\n"
            "pip install -r requirements-geo.txt"
        ) from exc


def find_column(columns: List[str], candidates: List[str]) -> Optional[str]:
    lower_map = {c.lower(): c for c in columns}
    for candidate in candidates:
        if candidate.lower() in lower_map:
            return lower_map[candidate.lower()]
    # fallback contains
    for c in columns:
        cl = c.lower()
        for candidate in candidates:
            if candidate.lower() in cl:
                return c
    return None


def prepare_dcah_gdf(dcah_path: Path):
    gpd = import_geopandas()

    if not dcah_path.exists():
        raise FileNotFoundError(f"No existe la capa DCAH: {dcah_path}")

    gdf = gpd.read_file(dcah_path)
    if gdf.empty:
        raise ValueError("La capa DCAH está vacía.")

    # Normalize field names without modifying geometry.
    cols = list(gdf.columns)

    cvegeo_col = find_column(cols, ["cvegeo_asen", "cve_geo", "cvegeo", "cvegeoah", "cve_asen_geo"])
    ent_col = find_column(cols, ["cve_ent", "cve_entidad", "entidad"])
    mun_col = find_column(cols, ["cve_mun", "cve_municipio", "municipio"])
    loc_col = find_column(cols, ["cve_loc", "cve_localidad", "localidad"])
    asen_col = find_column(cols, ["cve_asen", "cve_asentamiento", "asentamiento"])

    if cvegeo_col:
        gdf["cvegeo_asen_join"] = gdf[cvegeo_col].apply(lambda x: normalize_key(x))
    elif ent_col and mun_col and loc_col and asen_col:
        gdf["cvegeo_asen_join"] = (
            gdf[ent_col].apply(lambda x: normalize_key(x, 2))
            + gdf[mun_col].apply(lambda x: normalize_key(x, 3))
            + gdf[loc_col].apply(lambda x: normalize_key(x, 4))
            + gdf[asen_col].apply(lambda x: normalize_key(x, 4))
        )
    else:
        raise ValueError(
            "No pude identificar la clave del asentamiento en DCAH. "
            "La capa debe traer cve_geo/cvegeo o columnas cve_ent, cve_mun, cve_loc, cve_asen."
        )

    # Filter Hidalgo if possible
    gdf = gdf[gdf["cvegeo_asen_join"].str.startswith("13")].copy()

    if gdf.crs is None:
        # Most INEGI vector layers come with CRS, but if missing assume WGS84.
        gdf = gdf.set_crs("EPSG:4326")

    if gdf.crs.to_epsg() != 4326:
        gdf = gdf.to_crs("EPSG:4326")

    return gdf


def merge_asentamientos_with_dcah(df: pd.DataFrame, dcah_path: Path):
    gpd = import_geopandas()
    gdf_dcah = prepare_dcah_gdf(dcah_path)

    df = df.copy()
    df["cvegeo_asen_join"] = df["cvegeo_asen"].apply(lambda x: normalize_key(x))

    merged = gdf_dcah[["cvegeo_asen_join", "geometry"]].merge(
        df,
        how="inner",
        on="cvegeo_asen_join",
    )

    if merged.empty:
        raise ValueError(
            "No hubo coincidencias entre DCAH y el CSV de asentamientos. "
            "Revisa que la capa DCAH sea de Hidalgo y que las claves sean compatibles."
        )

    return gpd.GeoDataFrame(merged, geometry="geometry", crs="EPSG:4326")


def polygon_geojson_from_dcah(df: pd.DataFrame, dcah_path: Path) -> Dict[str, Any]:
    gdf = merge_asentamientos_with_dcah(df, dcah_path)

    gdf["geometria_modo"] = "poligono_dcah"
    gdf["nota_geometria"] = "Geometría real tomada de la capa DCAH de INEGI, cuando existe coincidencia de clave."

    drop_cols = [c for c in ["cvegeo_asen_join"] if c in gdf.columns]
    gdf = gdf.drop(columns=drop_cols)

    return gdf.__geo_interface__


def point_geojson_from_dcah(df: pd.DataFrame, dcah_path: Path) -> Dict[str, Any]:
    gpd = import_geopandas()
    gdf = merge_asentamientos_with_dcah(df, dcah_path)

    # representative_point is safer than centroid for irregular polygons.
    try:
        estimated_crs = gdf.estimate_utm_crs()
        gdf_projected = gdf.to_crs(estimated_crs) if estimated_crs else gdf
        points_projected = gdf_projected.geometry.representative_point()
        points = gpd.GeoSeries(points_projected, crs=gdf_projected.crs).to_crs("EPSG:4326")
    except Exception:
        points = gdf.geometry.representative_point()

    gdf = gdf.copy()
    gdf["geometry"] = points
    gdf["longitud_asen"] = gdf.geometry.x.astype(str)
    gdf["latitud_asen"] = gdf.geometry.y.astype(str)
    gdf["geometria_modo"] = "punto_representativo_dcah"
    gdf["nota_geometria"] = "Punto representativo calculado dentro del polígono DCAH."

    drop_cols = [c for c in ["cvegeo_asen_join"] if c in gdf.columns]
    gdf = gdf.drop(columns=drop_cols)

    return gdf.__geo_interface__


def write_geojson(path: Path, data: Dict[str, Any]) -> None:
    save_json(path, data)
    print(f"Generado: {path}")


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Genera GeoJSON enriquecido de asentamientos humanos de Hidalgo como puntos, polígonos o ambos."
    )

    parser.add_argument(
        "--input",
        default=str(OUTPUT_DIR_DEFAULT / "hidalgo_asentamientos_humanos.csv"),
        help="Ruta al CSV hidalgo_asentamientos_humanos.csv",
    )

    parser.add_argument(
        "--dcah",
        default="",
        help="Ruta al shapefile/GeoPackage de DCAH. Ejemplo: --dcah /ruta/a/DCAH.shp",
    )

    parser.add_argument(
        "--geometry",
        choices=["punto", "poligono", "both"],
        default="both",
        help="Tipo de salida: punto, poligono o both.",
    )

    parser.add_argument(
        "--output-dir",
        default=str(OUTPUT_DIR_DEFAULT),
        help="Carpeta de salida.",
    )

    args = parser.parse_args()

    input_path = Path(args.input)
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    df = load_asentamientos(input_path)

    main_output = output_dir / "hidalgo_asentamientos_humanos_enriquecido.geojson"
    point_output = output_dir / "hidalgo_asentamientos_humanos_enriquecido_puntos.geojson"
    polygon_output = output_dir / "hidalgo_asentamientos_humanos_enriquecido_poligonos.geojson"

    dcah_path = Path(args.dcah) if args.dcah else None

    if dcah_path:
        if args.geometry in ("punto", "both"):
            point_data = point_geojson_from_dcah(df, dcah_path)
            write_geojson(point_output, point_data)

        if args.geometry in ("poligono", "both"):
            polygon_data = polygon_geojson_from_dcah(df, dcah_path)
            write_geojson(polygon_output, polygon_data)

        # Main output preference:
        # - If polygon requested, use polygon as main.
        # - Else use point.
        if args.geometry in ("poligono", "both"):
            shutil.copyfile(polygon_output, main_output)
        else:
            shutil.copyfile(point_output, main_output)

        print(f"Archivo principal: {main_output}")
        return

    # No DCAH: only locality-based points are possible.
    if args.geometry == "poligono":
        raise ValueError(
            "No se puede generar polígono sin --dcah. "
            "Usa: python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry poligono"
        )

    point_data = point_geojson_from_locality(df)
    write_geojson(point_output, point_data)
    shutil.copyfile(point_output, main_output)
    print(f"Archivo principal: {main_output}")
    print("Modo usado: punto_localidad_preliminar.")


if __name__ == "__main__":
    main()
