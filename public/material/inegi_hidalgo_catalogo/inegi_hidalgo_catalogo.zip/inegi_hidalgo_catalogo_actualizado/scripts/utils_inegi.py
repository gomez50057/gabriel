from __future__ import annotations

import json
import time
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional

import requests


BASE_URL = "https://gaia.inegi.org.mx/wscatgeo/v2"
CVE_ENT_HIDALGO = "13"
NOM_ENT_HIDALGO = "Hidalgo"


def clean_text(value: Any) -> str:
    """Normalize values from INEGI responses."""
    if value is None:
        return ""
    return str(value).strip()


def zfill_or_empty(value: Any, size: int) -> str:
    value = clean_text(value)
    if not value:
        return ""
    return value.zfill(size)


def parse_int(value: Any, default: int = 0) -> int:
    value = clean_text(value)
    if value in ("", "-", "NA", "N/A", "None", "null"):
        return default
    try:
        return int(float(value))
    except Exception:
        return default


def make_session() -> requests.Session:
    session = requests.Session()
    session.headers.update(
        {
            "User-Agent": "Mozilla/5.0 (compatible; inegi-hidalgo-catalogo/1.0)",
            "Accept": "application/json,text/plain,*/*",
        }
    )
    return session


def get_datos(url: str, session: Optional[requests.Session] = None, retries: int = 3, sleep_seconds: float = 0.6) -> List[Dict[str, Any]]:
    """Fetch INEGI service response and return the `datos` list.

    The Catálogo Único service usually returns:
    {
      "datos": [...],
      "metadatos": {...},
      "numReg": ...
    }
    """
    session = session or make_session()

    last_error: Optional[Exception] = None

    for attempt in range(1, retries + 1):
        try:
            response = session.get(url, timeout=90)
            response.raise_for_status()
            data = response.json()

            if isinstance(data, dict):
                datos = data.get("datos", [])
                if isinstance(datos, list):
                    return datos
                return []

            if isinstance(data, list):
                return data

            return []

        except Exception as exc:
            last_error = exc
            if attempt < retries:
                time.sleep(sleep_seconds * attempt)

    raise RuntimeError(f"No se pudo consultar INEGI: {url}") from last_error


def save_json(path: Path, data: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")


def load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def normalize_municipio(raw: Dict[str, Any]) -> Dict[str, str]:
    cve_mun = zfill_or_empty(raw.get("cve_mun") or raw.get("cvegeo"), 3)
    # Some responses may expose cvegeo as 13048. Keep only last 3 if needed.
    if len(cve_mun) > 3:
        cve_mun = cve_mun[-3:]

    nom_mun = clean_text(raw.get("nomgeo") or raw.get("nom_mun") or raw.get("nombre"))

    return {
        "cve_ent": CVE_ENT_HIDALGO,
        "nom_ent": NOM_ENT_HIDALGO,
        "cve_mun": cve_mun,
        "nom_mun": nom_mun,
        "cvegeo_mun": f"{CVE_ENT_HIDALGO}{cve_mun}",
    }


def normalize_localidad(raw: Dict[str, Any], municipio: Dict[str, str]) -> Dict[str, Any]:
    cve_ent = CVE_ENT_HIDALGO
    cve_mun = municipio["cve_mun"]
    cve_loc = zfill_or_empty(raw.get("cve_loc"), 4)
    cvegeo_loc = clean_text(raw.get("cvegeo") or raw.get("cve_geo")) or f"{cve_ent}{cve_mun}{cve_loc}"

    return {
        "cve_ent": cve_ent,
        "nom_ent": NOM_ENT_HIDALGO,
        "cve_mun": cve_mun,
        "nom_mun": municipio["nom_mun"],
        "cve_loc": cve_loc,
        "nom_loc": clean_text(raw.get("nomgeo") or raw.get("nom_loc") or raw.get("nombre")),
        "ambito": clean_text(raw.get("ambito")).upper(),
        "latitud": clean_text(raw.get("latitud")),
        "longitud": clean_text(raw.get("longitud")),
        "altitud": clean_text(raw.get("altitud")),
        "pob_total": clean_text(raw.get("pob_total")),
        "periodo": clean_text(raw.get("periodo")),
        "cvegeo_loc": cvegeo_loc,
    }


def normalize_asentamiento(raw: Dict[str, Any], municipio: Dict[str, str], localidad_index: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    cve_ent = CVE_ENT_HIDALGO
    cve_mun = municipio["cve_mun"]
    cve_loc = zfill_or_empty(raw.get("cve_loc"), 4)
    cve_asen = zfill_or_empty(raw.get("cve_asen"), 4)

    loc = localidad_index.get(cve_loc, {})
    cvegeo_loc = clean_text(loc.get("cvegeo_loc")) or f"{cve_ent}{cve_mun}{cve_loc}"
    cvegeo_asen = clean_text(raw.get("cve_geo") or raw.get("cvegeo")) or f"{cve_ent}{cve_mun}{cve_loc}{cve_asen}"

    return {
        "cve_ent": cve_ent,
        "nom_ent": NOM_ENT_HIDALGO,
        "cve_mun": cve_mun,
        "nom_mun": municipio["nom_mun"],
        "cve_loc": cve_loc,
        "nom_loc": clean_text(loc.get("nom_loc")),
        "cve_asen": cve_asen,
        "nom_asen": clean_text(raw.get("nom_asen") or raw.get("nomgeo") or raw.get("nombre")),
        "tipo_asen": clean_text(raw.get("tipo_asen")).upper(),
        "periodo": clean_text(raw.get("periodo")),
        "cvegeo_loc": cvegeo_loc,
        "cvegeo_asen": cvegeo_asen,
        # Datos de localidad conservados para exportaciones tabulares y GeoJSON de puntos.
        # No se publican a nivel localidad dentro del JSON limpio.
        "ambito_loc": clean_text(loc.get("ambito")).upper(),
        "latitud_loc": clean_text(loc.get("latitud")),
        "longitud_loc": clean_text(loc.get("longitud")),
        "altitud_loc": clean_text(loc.get("altitud")),
        "pob_total_loc": clean_text(loc.get("pob_total")),
    }
