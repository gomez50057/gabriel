# Catálogo INEGI Hidalgo: Localidades y Asentamientos Humanos

Este paquete genera un catálogo de **localidades** y **asentamientos humanos** de Hidalgo usando datos de INEGI.

## Salidas principales

Al ejecutar el flujo base se generan estos archivos en `data/output/`:

```txt
hidalgo_localidades.csv
hidalgo_asentamientos_humanos.csv
hidalgo_asentamientos_humanos_localidades.csv
hidalgo_asentamientos_humanos_localidades.json
hidalgo_asentamientos_humanos_enriquecido.geojson
```

También puede generar salidas geográficas separadas:

```txt
hidalgo_asentamientos_humanos_enriquecido_puntos.geojson
hidalgo_asentamientos_humanos_enriquecido_poligonos.geojson
```

---

## Estructura del proyecto

```txt
inegi_hidalgo_catalogo/
├── data/
│   ├── raw/
│   ├── dcah/
│   └── output/
├── docs/
├── scripts/
│   ├── generar_catalogo_hidalgo.py
│   ├── generar_geojson_enriquecido.py
│   ├── run_all.py
│   └── utils_inegi.py
├── requirements.txt
├── requirements-geo.txt
└── README.md
```

---

## Instalación rápida

### Solo catálogo tabular y GeoJSON preliminar de puntos

```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python scripts/generar_catalogo_hidalgo.py
```

En Windows PowerShell:

```powershell
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python scripts\generar_catalogo_hidalgo.py
```

---

## Uso recomendado

### 1. Generar catálogo base desde INEGI

```bash
python scripts/generar_catalogo_hidalgo.py
```

Genera:

```txt
data/output/hidalgo_localidades.csv
data/output/hidalgo_asentamientos_humanos.csv
data/output/hidalgo_asentamientos_humanos_localidades.csv
data/output/hidalgo_asentamientos_humanos_localidades.json
data/output/hidalgo_asentamientos_humanos_enriquecido.geojson
```

El archivo `hidalgo_asentamientos_humanos_localidades.json` queda con esta estructura limpia:

```json
{
  "estado": "Hidalgo",
  "claveEntidad": "13",
  "claveGeoestadistica": "13",
  "tipo": "catalogo_asentamientos_humanos_localidades",
  "municipios": [
    {
      "municipio": "Pachuca de Soto",
      "claveMunicipio": "048",
      "claveGeoestadistica": "13048",
      "localidades": [
        {
          "claveGeoestadistica": "130480001",
          "claveLocalidad": "0001",
          "nombre": "Pachuca de Soto",
          "ambito": "URBANO",
          "periodo": "2015-06-01",
          "tipo": "localidad",
          "asentamientosHumanos": []
        }
      ],
      "resumen": {
        "total": 35,
        "localidades": 35,
        "asentamientos": 430,
        "urbanas": 3,
        "rurales": 32,
        "poblacionTotal": 314313
      }
    }
  ],
  "resumen": {
    "municipios": 84,
    "localidades": 5291,
    "asentamientos": 3843,
    "urbanas": 263,
    "rurales": 5028,
    "poblacionTotal": 3082756
  }
}
```

> Nota: `latitud`, `longitud`, `altitud` y `pob_total` **no se dejan a nivel localidad** dentro del JSON limpio. La población se concentra en `resumen.poblacionTotal` a nivel municipal y estatal.

---

# GeoJSON enriquecido

## Modalidad 1: puntos preliminares

Si no tienes la capa DCAH, puedes generar un GeoJSON de **puntos preliminares** usando la coordenada de la localidad como referencia.

```bash
python scripts/generar_geojson_enriquecido.py --geometry punto
```

Salida:

```txt
data/output/hidalgo_asentamientos_humanos_enriquecido_puntos.geojson
data/output/hidalgo_asentamientos_humanos_enriquecido.geojson
```

En este modo, cada asentamiento humano queda como punto usando `latitud_loc` y `longitud_loc`.

> Importante: este punto representa la **localidad**, no la geometría real del asentamiento humano.

---

## Modalidad 2: polígonos reales DCAH

Para tener geometría real de colonias/asentamientos, el proyecto incluye:

```bash
python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry poligono
```

Salida:

```txt
data/output/hidalgo_asentamientos_humanos_enriquecido_poligonos.geojson
data/output/hidalgo_asentamientos_humanos_enriquecido.geojson
```

Este modo usa la capa DCAH de INEGI y genera geometrías de tipo `Polygon` o `MultiPolygon` cuando la capa contiene la delimitación.

---

## Modalidad 3: puntos y polígonos al mismo tiempo

```bash
python scripts/generar_geojson_enriquecido.py --dcah /ruta/a/DCAH.shp --geometry both
```

Salidas:

```txt
data/output/hidalgo_asentamientos_humanos_enriquecido_puntos.geojson
data/output/hidalgo_asentamientos_humanos_enriquecido_poligonos.geojson
data/output/hidalgo_asentamientos_humanos_enriquecido.geojson
```

En este caso:

- `*_poligonos.geojson` conserva la geometría real del asentamiento humano.
- `*_puntos.geojson` calcula un `representative_point()` dentro del polígono.
- `hidalgo_asentamientos_humanos_enriquecido.geojson` apunta por defecto a la versión de polígonos.

---

## Instalar dependencias geográficas

Para usar DCAH necesitas instalar dependencias GIS:

```bash
pip install -r requirements-geo.txt
```

Si estás en Linux y falla `geopandas` o `pyogrio`, instala primero librerías del sistema:

```bash
sudo dnf install -y gdal gdal-devel geos geos-devel proj proj-devel
```

En Ubuntu/Debian:

```bash
sudo apt install -y gdal-bin libgdal-dev libgeos-dev libproj-dev
```

---

# Diferencia entre puntos y polígonos

| Salida | Qué representa | Precisión |
|---|---|---|
| `*_puntos.geojson` sin DCAH | Punto de la localidad asociada | Baja / referencial |
| `*_puntos.geojson` con DCAH | Punto representativo del polígono del asentamiento | Alta |
| `*_poligonos.geojson` con DCAH | Delimitación real del asentamiento humano | Alta |
| `hidalgo_asentamientos_humanos_enriquecido.geojson` | Archivo principal de salida | Depende del modo |

---

# Campos principales

## Localidad en JSON limpio

```json
{
  "claveGeoestadistica": "130480001",
  "claveLocalidad": "0001",
  "nombre": "Pachuca de Soto",
  "ambito": "URBANO",
  "periodo": "2015-06-01",
  "tipo": "localidad",
  "asentamientosHumanos": []
}
```

## Asentamiento humano

```json
{
  "claveAsentamiento": "0152",
  "nombre": "ADOLFO LÓPEZ MATEOS",
  "tipoAsentamiento": "COLONIA",
  "periodo": "11/2024",
  "claveGeoestadistica": "1304800010152",
  "claveLocalidad": "0001",
  "claveGeoestadisticaLocalidad": "130480001",
  "localidad": "Pachuca de Soto",
  "tipo": "asentamiento"
}
```

## Resumen municipal

```json
{
  "total": 35,
  "localidades": 35,
  "asentamientos": 430,
  "urbanas": 3,
  "rurales": 32,
  "poblacionTotal": 314313
}
```

---

# Nota técnica sobre población

El catálogo tabular de asentamientos humanos no trae población propia por colonia/asentamiento.

Por eso:

- `poblacionTotal` se calcula por suma de localidades del municipio.
- No se asigna población directa a cada asentamiento humano.
- Para población por asentamiento sería necesario cruzar polígonos DCAH con datos censales por manzana/AGEB.

---

# Fuentes de datos

El paquete usa el servicio web del Catálogo Único de Claves Geoestadísticas de INEGI:

```txt
https://gaia.inegi.org.mx/wscatgeo/v2
```

Endpoints usados:

```txt
/mgem/13
/localidades/13/{cve_mun}
/asentamientos/13/{cve_mun}
```

Para geometría real se usa la capa DCAH de INEGI:

```txt
Delimitación de colonias y otros asentamientos humanos
```


---

## CSV combinado de localidades y asentamientos humanos

El archivo nuevo:

```txt
data/output/hidalgo_asentamientos_humanos_localidades.csv
```

tiene una estructura plana para usar en Excel, bases de datos o importaciones.

### Columnas

```txt
estado
claveEntidad
municipio
claveMunicipio
claveGeoestadisticaMunicipio
localidad
claveLocalidad
claveGeoestadisticaLocalidad
ambito
periodoLocalidad
asentamientoHumano
claveAsentamiento
tipoAsentamiento
periodoAsentamiento
claveGeoestadisticaAsentamiento
tipoRegistro
```

### Regla de filas

- Si la localidad tiene asentamientos humanos, genera una fila por cada asentamiento.
- Si la localidad no tiene asentamientos humanos, genera una fila con `tipoRegistro = localidad_sin_asentamiento`.
- No incluye `latitud`, `longitud`, `altitud` ni `pob_total` a nivel localidad.
- La población se conserva solamente en el resumen municipal y estatal del JSON.

